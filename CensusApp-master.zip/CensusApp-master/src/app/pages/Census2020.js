import React from "react";
import Disclaimer from "../components/public/Disclaimer";
import DecennialAppbar from "../components/decennial2020/DecennialAppbar";
import SketchWidgetPaperPie from "../components/public/SketchWidgetPaperPie";
import Info from "../components/public/Info";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import {
  changeCategory,
  changeSurvey,
  updateDrawer,
  updateLayer,
} from "../redux/actions";
//6/29/23 update: we ditched the block group map and returned to the tract map
//import Map from '../components/decennial2020/Map2020';
import Map from "../components/public/Map";
import Drawer2020 from "../components/decennial2020/Drawer2020";

const Census2020 = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(changeCategory("Population"));
    dispatch(changeSurvey("2020"));
    //6/29/23 update: we ditched the block group map and returned to the tract map
    //dispatch(updateLayer('blockgroups'));
    dispatch(updateLayer("tracts"));
    return () => {
      dispatch(updateLayer(null));
      dispatch(updateDrawer(false));
    };
  }, []);
  return (
    <div>
      <Disclaimer>
        All data are retrieved from the 2020 Decennial Census Demographic and
        Housing Characteristics File (DHC) provided by the U.S. Census Bureau.
        <br />
        For data definitions, please visit{" "}
        <a href="https://www.census.gov/glossary" target="_blank">
          Census Glossary
        </a>
        .
        <br />
        For Boston-specific data tables, please visit{" "}
        <a
          href="https://data.boston.gov/dataset/2020-census-for-boston"
          target="_blank"
        >
          2020 Census for Boston
        </a>
        .
      </Disclaimer>
      <Info>
        The U.S. Census Bureau conducts the decennial census every ten years to
        provide an official count of the entire U.S. population to Congress for
        apportionment of taxes and representation in the House of
        Representatives. The 2020 Decennial Census is the latest Decennial
        Census that counted residents in the United States on April 1st, 2020
        and asked a short set of additional questions, such as age, sex, race,
        Hispanic origin, and owner/renter status. The 2020 Decennial Census
        questionnaire can be found here:{" "}
        <a
          href="https://www2.census.gov/programs-surveys/decennial/2020/technical-documentation/questionnaires-and-instructions/questionnaires/2020-informational-questionnaire-english_DI-Q1.pdf"
          target="_blank"
        >
          2020 Decennial Census Survey Questions
        </a>
        . More details of the 2020 Decennial Census can be found here:{" "}
        <a
          href="https://www.census.gov/programs-surveys/decennial-census/decade/2020/about.html"
          target="_blank"
        >
          About the 2020 Census
        </a>
        .
        <br />
        <br />
        All data in this map are drawn from the 2020 Census Demographic and
        Housing Characteristics File (DHC). For a complete official file
        documentation, please go to{" "}
        <a
          href="https://www2.census.gov/programs-surveys/decennial/2020/technical-documentation/complete-tech-docs/demographic-and-housing-characteristics-file-and-demographic-profile/2020census-demographic-and-housing-characteristics-file-and-demographic-profile-techdoc.pdf"
          target="_blank"
        >
          2020 Census Demographic and Housing Characteristics File (DHC)
          Technical Documentation
        </a>
        . For Boston data tables, please visit{" "}
        <a
          href="https://data.boston.gov/dataset/2020-census-for-boston"
          target="_blank"
        >
          2020 Census for Boston
        </a>
        . Full 2020 Census data are not scheduled to be released until 2022.
        <br />
        <br />
        Census tracts are statistical areas defined by Census. The census tract
        boundaries in this map were defined at the time of the 2020 Decennial
        Census. Census tract boundaries are drawn by the Census Bureau and have
        a population size between 1,200 to 8,000, with an optimal population of
        4,000. For more information, please visit{" "}
        <a
          href="https://www.census.gov/programs-surveys/geography/about/glossary.html#par_textimage_13"
          target="_blank"
        >
          Glossary on census.gov
        </a>
        <br />
        <br />
        Boston neighborhoods are not recognized by the U.S. Census and the
        Census does not report data by neighborhood. Therefore, the City Of Boston Planning Department uses
        census tracts to approximate Boston neighborhoods as shown in this map:{" "}
        <a
          href="https://bpda.box.com/s/hkodl53x67qua9rbz8lo83y6ocm2lfgc"
          target="_blank"
        >
          2020 Census Tracts and Neighborhoods.
        </a>
        .
        <br />
        <br />
        <a
          href="http://www.bostonplans.org/research/research-inquiries"
          target="_blank"
        >
          Contact Us
        </a>
      </Info>
      <DecennialAppbar />
      <Drawer2020 />
      <Map />
      <SketchWidgetPaperPie />
    </div>
  );
};

export default Census2020;
