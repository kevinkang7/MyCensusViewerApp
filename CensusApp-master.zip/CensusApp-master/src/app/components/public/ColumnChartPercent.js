import React from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import style from "./ColumnChart.css";

Highcharts.setOptions({
  lang: {
    decimalPoint: ".",
    thousandsSep: ",",
  },
});

const ColumnChartPercent = (props) => {
  const { title, data, chartData, yCategory, seperate } = props;
  let chart = chartData ? chartData : data;
  const categories = [];
  let series = [];

  for (let category of yCategory) {
    series.push({
      name: category,
      data: [],
    });
  }
  chart.forEach((array) => {
    if (!array[0].includes("Total")) {
      categories.push(array[0]);

      for (let i = 1; i <= yCategory.length; i++) {
        if (!array[i]) {
          array[i] = 0;
        }
        series[i - 1].data.push(array[i]);
      }
    }
  });
  console.log(series);

  const options = {
    chart: {
      type: "column",
    },
    title: {
      text: title,
    },
    xAxis: {
      categories: categories,
      type: "category",
      labels: {
        rotation: -45,
        style: {
          fontSize: "13px",
          fontFamily: "Verdana, sans-serif",
        },
      },
    },

    yAxis: {
      title: {
        text: "Percentage",
      },
      labels: { format: "{value:.0f}%" },
    },

    tooltip: {
      //pointFormat: "{point.y:,.1f}",
      pointFormat: "{point.y:.1f}%",
    },
    plotOptions: {
      column: {
        pointPadding: 0.1,
        borderWidth: 1,
      },
      series: {
        dataLabels: {
          enabled: true,
          //color: "#FFFFFF",
          //  align: "right",
          format: "{point.y:.1f}%", // one decimal
        },
      },
    },
    series: series,
  };

  console.log(options.series);
  return (
    <div className={style.container}>
      <HighchartsReact highcharts={Highcharts} options={options} />
    </div>
  );
};

export default ColumnChartPercent;
