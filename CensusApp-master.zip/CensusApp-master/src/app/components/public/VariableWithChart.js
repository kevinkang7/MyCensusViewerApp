import React from "react";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Collapse from "@material-ui/core/Collapse";
import Divider from "@material-ui/core/Divider";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import Box from "@material-ui/core/Box";
import DownloadCSV from "./DownloadCSV";
import PieChart from "./PieChart";
import ColumnChart from "./ColumnChart";
import ColumnChartNormal from "./ColumnChartNormal";
import ColumnChartPercent from "./ColumnChartPercent";
import BarChart from "./BarChart";
import BarChartDollar from "./BarChartDollar";
import { connect } from "react-redux";
import DataTable from "./DataTable";
import style from "./VariableWithChart.css";

//2023.8.7: create the second chart parameter: chart2, chartData2, yCategory2

const VariableWithChart = (props) => {
  const { open, info } = props;
  const {
    data,
    csv,
    title,
    chart,
    chart2,
    header,
    chartData,
    chartData2,
    yCategory,
    yCategory2,
    notes,
    tableID,
    universe,
  } = info;
  let chartDiv;
  let chartDiv2;
  if (chart === "pie") {
    chartDiv = <PieChart data={data} title={title} chartData={chartData} />;
  } else if (chart === "column") {
    chartDiv = (
      <ColumnChart
        data={data}
        header={header}
        chartData={chartData}
        yCategory={yCategory}
      />
    );
  } else if (chart === "columnNormal") {
    chartDiv = (
      <ColumnChartNormal
        data={data}
        header={header}
        chartData={chartData}
        yCategory={yCategory}
      />
    );
  } else if (chart === "columnPercent") {
    chartDiv = (
      <ColumnChartPercent
        data={data}
        header={header}
        chartData={chartData}
        yCategory={yCategory}
      />
    );
  } else if (chart === "bar") {
    chartDiv = (
      <BarChart
        data={data}
        header={header}
        chartData={chartData}
        yCategory={yCategory}
      />
    );
  } else if (chart === "barDollar") {
    chartDiv = (
      <BarChartDollar
        data={data}
        header={header}
        chartData={chartData}
        yCategory={yCategory}
      />
    );
  }
  if (chart2 === "columnPercent") {
    chartDiv2 = (
      <ColumnChartPercent
        data={data}
        header={header}
        chartData={chartData2}
        yCategory={yCategory2}
      />
    );
  }

  return (
    <div>
      <Divider />
      <Collapse in={open} timeout="auto">
        {data.length ? (
          <div className={style.container}>
            <div className={style.info}>
              <b>Table ID:</b> {tableID}
            </div>
            <div className={style.info}>
              <b>Universe:</b> {universe}
            </div>
            <DataTable
              data={data}
              header={header}
              tableID={tableID}
              universe={universe}
            />
            {chartDiv}
            {chartDiv2 === null ? null : chartDiv2}
            {notes ? (
              <Box
                display="flex"
                justifyContent="center"
                fontWeight="bold"
                fontSize={13}
                mt={0.5}
                mb={0.5}
                marginRight={2}
                marginLeft={2}
              >
                {notes}
              </Box>
            ) : null}

            <ListItem>
              <ListItemIcon>
                <DownloadCSV
                  data={csv}
                  title={title}
                  selected={props.mapState.selected}
                />
              </ListItemIcon>
              <ListItemText primary="download csv" />
            </ListItem>
          </div>
        ) : (
          <Box
            display="flex"
            justifyContent="center"
            fontSize={17}
            mt={3}
            mb={3}
          >
            Please select only one census tract to view the data
          </Box>
        )}
      </Collapse>
      <Divider />
    </div>
  );
};

const mapStateToProps = (state) => ({
  mapState: state.map,
});

export default connect(mapStateToProps)(VariableWithChart);
