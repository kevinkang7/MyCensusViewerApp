//const census = require("citysdk");
import census from "citysdk";

// load ACS data from census API
export const _loadAsyncData = (props, values) => {
  console.log(props.mapState.selected);
  let Args =
    props.mapState.layer === "city"
      ? {
          vintage: 2022,
          geoHierarchy: {
            state: "25",
            county: "025",
            "county subdivision": "07000",
          },
          sourcePath: ["acs", "acs5"],
          values: [values],
        }
      : {
          vintage: 2022,
          geoHierarchy: {
            state: "25",
            county: "025",
            tract: props.mapState.selected.join(","),
          },
          sourcePath: ["acs", "acs5"],
          values: [values],
        };
  console.log(values);
  return new Promise((resolve, reject) => {
    census(Args, (err, res) => {
      if (err) {
        reject(err);
      } else {
        //res is an array, it only has one element, and it's an object: [{}]
        console.log(res[0]);

        let keys = Object.keys(res[0]);
        let tempObj = {};
        keys.forEach((key) => {
          let temp = 0;
          for (var i = 0; i < res.length; i++) {
            temp += parseInt(res[i][key]);
          }
          tempObj[key] = temp;
        });
        resolve([tempObj, res]);
        console.log([tempObj, res]);
      }
    });
  });
};

// load ACS subject table data from census API

export const _loadAsyncData_S_Table = (props, values) => {
  console.log(props.mapState.selected);
  let Args =
    props.mapState.layer === "city"
      ? {
          vintage: 2022,
          geoHierarchy: {
            state: "25",
            county: "025",
            "county subdivision": "07000",
          },
          sourcePath: ["acs", "acs5", "subject"],
          values: [values],
        }
      : {
          vintage: 2022,
          geoHierarchy: {
            state: "25",
            county: "025",
            tract: props.mapState.selected.join(","),
          },
          sourcePath: ["acs", "acs5", "subject"],
          values: [values],
        };
  console.log(values);
  return new Promise((resolve, reject) => {
    census(Args, (err, res) => {
      if (err) {
        reject(err);
      } else {
        //res is an array, it only has one element, and it's an object: [{}]
        console.log(res[0]);

        let keys = Object.keys(res[0]);
        let tempObj = {};
        keys.forEach((key) => {
          let temp = 0;
          for (var i = 0; i < res.length; i++) {
            temp += parseInt(res[i][key]);
          }
          tempObj[key] = temp;
        });
        resolve([tempObj, res]);
        console.log([tempObj, res]);
      }
    });
  });
};

// load DHC data from census API
export const _loadCensus2020Data_DHC = (props, values) => {
  console.log(props.mapState.selected);
  let Args =
    props.mapState.layer === "city"
      ? {
          vintage: "2020",
          geoHierarchy: {
            state: "25",
            county: "025",
            "county subdivision": "07000",
          },
          sourcePath: ["dec", "dhc"],
          values: [values],
        }
      : {
          vintage: "2020",
          geoHierarchy: {
            state: "25",
            county: "025",

            tract: props.mapState.selected.join(","),
          },
          sourcePath: ["dec", "dhc"],
          values: [values],
        };
  console.log(values);
  return new Promise((resolve, reject) => {
    census(Args, (err, res) => {
      if (err) {
        reject(err);
      } else {
        console.log(res);

        let keys = Object.keys(res[0]);

        //2023.8.16: res is an array, it has one object if one tract is queried: [{}], multiple objects if multiple tracts are queried: [{},{},{},...]
        //sumTractsData: sum a variable data from multiple tracts, remove NAME, GEO_ID, state, county, tracts that should not be summed.
        let keys_varOnly = [];
        keys_varOnly = keys.filter(
          (e) =>
            e !== "NAME" &&
            e !== "GEO_ID" &&
            e !== "state" &&
            e !== "county" &&
            e !== "tract"
        );

        //sum up variable data from multiple tracts from res array
        let obj_sumTractsData = {};
        keys_varOnly.forEach((key) => {
          let temp = 0;
          for (var i = 0; i < res.length; i++) {
            temp += parseInt(res[i][key]);
          }
          obj_sumTractsData[key] = temp;
        });

        resolve([obj_sumTractsData, res]);
        console.log([obj_sumTractsData, res]);
      }
    });
  });
};

//load Census 2020 Redistricting data from census API
export const _loadCensus2020Data = (layer, selected, variables) => {
  console.log(selected);
  const variablesCount = variables.length;

  const args = [];
  //2023 updates: remove blockgroups, and replace it with the tract
  // if (layer === "blockgroups") {
  //   selected.forEach((bgid) => {
  //     variables.forEach((variable) => {
  //       args.push({
  //         vintage: "2020",
  //         geoHierarchy: {
  //           state: "25",
  //           county: "025",
  //           tract: bgid.substring(0, 6),
  //           "block-group": bgid.substring(6),
  //         },
  //         sourcePath: ["dec", "pl"],
  //         values: [variable],
  //       });
  //     });
  //   });
  // }

  if ((layer === "tracts") | (layer === "neighborhood")) {
    selected.forEach((tract) => {
      variables.forEach((variable) => {
        args.push({
          vintage: "2020",
          geoHierarchy: {
            state: "25",
            county: "025",
            tract: tract,
          },
          sourcePath: ["dec", "pl"],
          values: [variable],
        });
      });
    });
  } else if (layer === "city") {
    variables.forEach((variable) => {
      args.push({
        vintage: "2020",
        geoHierarchy: {
          state: "25",
          county: "025",
          "county subdivision": "07000",
        },
        sourcePath: ["dec", "pl"],
        values: [variable],
      });
    });
  }

  const promises = [];
  args.forEach((arg) => {
    promises.push(
      new Promise((resolve, reject) => {
        census(arg, (err, res) => {
          if (err) {
            reject(err);
          } else {
            resolve(res);
          }
        });
      })
    );
  });

  return Promise.all(promises).then((res) => {
    let result = [];
    //variablesCount ===1, one call every time. Deal with the group quarter call and the housing call.
    if (variablesCount === 1) {
      //   res.forEach((blockgroup) => {
      //     result.push(blockgroup[0]);
      //   });
      // }s
      console.log(promises);
      console.log(res);
      // for (let i = 0; i < res.length - 1; i = i + 2) {
      //   result.push({ ...res[i][0], ...res[i + 1][0] });
      // }
      //kk: not sure why result returns to number format ????? now it works... tbd...
      //
      for (let i = 0; i < res.length; i++) {
        console.log(res[0]);
        result.push({ ...res[i][0] });
        console.log(result);
      }
    }

    //KK: this is an ad hoc solution. when API call, it calls two group variables. P2 and P4
    //so it returns two arrays for each call.
    //have to aggregate two arrays for every block group, that's what ...res[i][0], ...res[i + 1][0] does
    else if (variablesCount === 2) {
      console.log(res);
      for (let i = 0; i < res.length - 1; i = i + 2) {
        result.push({ ...res[i][0], ...res[i + 1][0] });
      }
    }

    console.log(result);
    console.log(selected);
    //KK: unnecessary codes by PJ
    // combine values from different groups into single object
    // result.forEach((selected) => {
    //   for (const key in selected) {
    //     selected[key] = parseInt(selected[key]);
    //   }
    // });

    return result;
  });
};
