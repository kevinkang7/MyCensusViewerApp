import React from "react";
import LoadingBlock from "../public/LoadingBlock";
import { connect } from "react-redux";
//import { process2020CsvData } from "../public/utils";
import { processCsvData } from "../public/utils";
import { _loadCensus2020Data } from "../public/api_census";
import EmptyMessage from "../public/EmptyMessage";
import { clearData, updateGroupQuarters } from "../../redux/actions";
import VariableWithChart from "../public/VariableWithChart";
import ColumnChart from "../public/ColumnChart";
import ChartCentered from "../public/ChartCentered";

class GroupQuarters extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
    };
  }

  setDataToState = async () => {
    const { layer, neighborhood, selected } = this.props.mapState;
    this.setState({ loading: true });
    const data = await _loadCensus2020Data(layer, selected, ["group(P5)"]);

    console.log(data);

    this.props.dispatch(
      updateGroupQuarters({
        selected: this.props.mapState.selected,
        data: [
          {
            title: "Group Quarters Population",
            data: this.generateTableData(data),
            chart: "column",
            //2023.8 update: remove process2020CsvData
            // csv: process2020CsvData(
            //   data,
            //   this.processData,
            //   ["", "Population"],
            //   [],
            //   layer,
            //   neighborhood
            // ),
            csv: processCsvData(
              data,
              this.processData,
              ["", "Population"],
              this.generateTableData(data),
              layer,
              neighborhood
            ),
            header: ["", "Population"],
            yCategory: ["Population"],
            tableID: "DHC(P18)/Redistricting(P5)",
            universe: "Population in group quarters",
            notes: (
              <div>
                Note: The Census Bureau accepted the City of Boston's Post
                Census Group Quarters Review in 2022. The population is adjusted
                accordingly and{" "}
                <a
                  href="https://bpda.box.com/s/8nxvij9ccj18h2n8ezo9nmnuvdn6390m"
                  target="_blank"
                >
                  available
                </a>{" "}
                at the tract, neigborhood, and city levels.
              </div>
            ),
          },
        ],
      })
    );

    this.setState({ loading: false });
  };

  componentDidMount() {
    const { mapState, dataState } = this.props;
    if (
      (!dataState.groupQuarters ||
        dataState.groupQuarters.selected !== mapState.selected) &&
      (mapState.selected.length !== 0 || mapState.layer == "city")
    ) {
      this.setDataToState(this.props);
    }
  }
  componentDidUpdate(prevProps) {
    if (prevProps.mapState.selected !== this.props.mapState.selected) {
      if (
        this.props.mapState.selected.length !== 0 ||
        this.props.mapState.layer == "city"
      ) {
        this.setDataToState(this.props);
      } else {
        this.props.dispatch(clearData());
      }
    }
  }

  combineData = (data) => {
    const result = {};
    const keys = Object.keys(data[0]);
    keys.forEach((key) => {
      let temp = 0;
      data.forEach((item) => {
        temp += parseInt(item[key]);
      });
      result[key] = temp;
    });
    return result;
  };

  processData = (data) => [
    ["Correctional facilities for adults", data.P5_003N],
    ["Juvenile facilities", data.P5_004N],
    ["Nursing facilities/Skilled-nursing facilities", data.P5_005N],
    ["Other institutional facilities", data.P5_006N],
    ["College/University student housing", data.P5_008N],
    ["Military quarters", data.P5_009N],
    ["Other noninstitutional facilities", data.P5_010N],
    ["Total", data.P5_001N],
  ];

  generateTableData = (rawData) => {
    return this.processData(this.combineData(rawData));
  };

  render() {
    if (this.props.dataState.groupQuarters && !this.state.loading) {
      return (
        <div>
          {this.props.dataState.groupQuarters.data.map((part, index) => (
            <div key={index}>
              <VariableWithChart open={true} info={part} />

              {
                //2023.12 update: we will use column chart in the "VariableWithChart" parameters to draw the chart. Rather than using ChartCentered component.
                /* <ChartCentered
                data={part.data}
                yCategory={part.yCategory}
                Component={ColumnChart}
              /> */
              }
            </div>
          ))}
        </div>
      );
    } else if (this.state.loading) {
      console.log("LOADING");
      return <LoadingBlock />;
    } else {
      return <EmptyMessage />;
    }
  }
}

const mapStateToProps = (state) => ({
  mapState: state.map,
  dataState: state.data,
});

export default connect(mapStateToProps)(GroupQuarters);
