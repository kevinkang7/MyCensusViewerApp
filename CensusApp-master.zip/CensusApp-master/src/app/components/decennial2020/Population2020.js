import React from "react";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import LoadingBlock from "../public/LoadingBlock";
import { connect } from "react-redux";
import { processCsvData } from "../public/utils";
import { _loadCensus2020Data_DHC } from "../public/api_census";
import EmptyMessage from "../public/EmptyMessage";
import { updatePopulation, clearData } from "../../redux/actions";
import VariableWithChart from "../public/VariableWithChart";

class Population2020 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      age: false,
      gender: false,
      race: false,
    };
  }

  setDataToState = (props) => {
    const { layer, neighborhood } = this.props.mapState;
    this.setState({ loading: true });
    const ageSexPromise = _loadCensus2020Data_DHC(props, "group(P12)");
    const racePromise = _loadCensus2020Data_DHC(props, "group(P9)");
    const raceAdultPromise = _loadCensus2020Data_DHC(props, "group(P11)");

    Promise.all([ageSexPromise, racePromise, raceAdultPromise]).then(
      (values) => {
        const ageHeader = ["Age", "Count"];
        const genderHeader = ["Sex", "Count"];
        const raceAdultChildHeader = [
          "Race/Ethnicity",
          "Total Population",
          "Adult Population (Age 18 and Over)",
          "Child Population (Under Age 18)",
        ];
        console.log(values);
        //values is an array including all promises [   [{},[{},{},{}]],  [{},[{},{},{}]],   [{},[{},{},{}]]    ]: one element, one variable [{},[{},{},{}]]

        const ageData = this.processAgeData(values[0][0]);
        const genderData = this.processGenderData(values[0][0]);
        //we need to combine group(P9):total population group(11): adult population
        //values(two variables and three tracts example):[      [{},[{},{}]],         [{},[{},{}]] ]
        //[[{tempObj_combinedTractsData_var1},[{res_tract1},{res_tract2},{res_tract3}]],[{tempObj_combinedTractsData_var2},[{res_tract1},{res_tract2},{res_tract3}]]]
        // values[1][0] is an object within array "values[1][0]", that's why we combine objects using {...,  ...}
        // for chart table, we combine multivariables using values {...,  ...} values[1][0] and values[2][0] are tracts sum values
        const raceAllAdultData = { ...values[1][0], ...values[2][0] };
        // for csv table, we combine multivariables using values {...,  ...}, but we have to combine variables for each single tract
        const raceAdultChildData =
          this.processRaceAdultChildData(raceAllAdultData);
        //loop the selected tracts
        const raceAllAdultData_csv = [];
        for (let i = 0; i < values[1][1].length; i++) {
          raceAllAdultData_csv.push({
            ...values[1][1][i],
            ...values[2][1][i],
          });
        }
        console.log(raceAllAdultData_csv);

        const raceAdultChildPercentData =
          this.processRaceAdultChildPercentData(raceAllAdultData);

        //     console.log(raceAllAdultData);

        const chartData1 = raceAdultChildData.map((item) => {
          return item.slice(0, 2);
        });
        const chartData2 = raceAdultChildPercentData;

        console.log(raceAdultChildData);
        console.log(raceAdultChildPercentData);

        console.log(chartData1);
        this.props.dispatch(
          updatePopulation({
            selected: this.props.mapState.selected2,
            data: [
              {
                id: "age",
                title: "Population by Age",
                chart: "bar",
                data: ageData,
                csv: processCsvData(
                  values[0][1],
                  this.processAgeData,
                  ageHeader,
                  ageData,
                  layer,
                  neighborhood
                ),
                header: ageHeader,
                yCategory: ["Count"],
                tableID: "P12",
                universe: "Total population",
                notes: (
                  <div>
                    Note: The Census Bureau accepted the City of Boston's Post
                    Census Group Quarters Review in 2022. The population is
                    adjusted accordingly and{" "}
                    <a
                      href="https://bpda.box.com/s/8nxvij9ccj18h2n8ezo9nmnuvdn6390m"
                      target="_blank"
                    >
                      available
                    </a>{" "}
                    at the tract, neigborhood, and city levels.
                  </div>
                ),
              },

              {
                id: "gender",
                title: "Sex",
                chart: "pie",
                data: genderData,
                csv: processCsvData(
                  values[0][1],
                  this.processGenderData,
                  genderHeader,
                  genderData,
                  layer,
                  neighborhood
                ),
                header: genderHeader,
                yCategory: ["Count"],
                tableID: "P12",
                universe: "Total population",
                notes: (
                  <div>
                    Note: The Census Bureau accepted the City of Boston's Post
                    Census Group Quarters Review in 2022. The population is
                    adjusted accordingly and{" "}
                    <a
                      href="https://bpda.box.com/s/8nxvij9ccj18h2n8ezo9nmnuvdn6390m"
                      target="_blank"
                    >
                      available
                    </a>{" "}
                    at the tract, neigborhood, and city levels.
                  </div>
                ),
              },
              {
                id: "race",
                title: "Race/Ethnicity",
                chart: "pie",
                chart2: "columnPercent",
                data: raceAdultChildData,
                chartData: chartData1,
                chartData2: chartData2,
                csv: processCsvData(
                  raceAllAdultData_csv,
                  this.processRaceAdultChildData,
                  raceAdultChildHeader,
                  raceAdultChildData,
                  layer,
                  neighborhood
                ),
                header: raceAdultChildHeader,
                yCategory: ["Count"],
                yCategory2: [
                  "Adult Population (Age 18 and Over) Share by Race/Ethnicity",
                  "Child Population (Under Age 18) Share by Race/Ethnicity",
                ],
                tableID: "P9, P11",
                universe: "Total population",
                notes: (
                  <div>
                    Note: The Census Bureau accepted the City of Boston's Post
                    Census Group Quarters Review in 2022. The population is
                    adjusted accordingly and{" "}
                    <a
                      href="https://bpda.box.com/s/8nxvij9ccj18h2n8ezo9nmnuvdn6390m"
                      target="_blank"
                    >
                      available
                    </a>{" "}
                    at the tract, neigborhood, and city levels.
                  </div>
                ),
              },
            ],
          })
        );

        this.setState({ loading: false });
      }
    );
  };

  componentDidMount() {
    const { mapState, dataState } = this.props;
    if (
      (!dataState.population ||
        dataState.population.selected !== mapState.selected) &&
      (mapState.selected.length !== 0 || mapState.layer == "city")
    ) {
      this.setDataToState(this.props);
    }
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevProps.mapState.selected !== this.props.mapState.selected) {
      if (
        this.props.mapState.selected.length !== 0 ||
        this.props.mapState.layer == "city"
      ) {
        this.setDataToState(this.props);
      } else {
        this.props.dispatch(clearData());
      }
    }
  }

  processGenderData = (data) => {
    return [
      ["Male", parseInt(data["P12_002N"])],
      ["Female", parseInt(data["P12_026N"])],
      ["Total", parseInt(data["P12_001N"])],
    ];
  };

  processAgeData(data) {
    //0-4
    //P12_003N + P12_027N
    let temp1_m = parseInt(data["P12_003N"]);
    let temp1_f = parseInt(data["P12_027N"]);
    let temp1 = temp1_m + temp1_f;

    //5-17
    //(P12_004N + P12_028N) + (P12_005N + P12_029N) + (P12_006N + P12_030N)
    let temp2_m =
      parseInt(data["P12_004N"]) +
      parseInt(data["P12_005N"]) +
      parseInt(data["P12_006N"]);
    let temp2_f =
      parseInt(data["P12_028N"]) +
      parseInt(data["P12_029N"]) +
      parseInt(data["P12_030N"]);
    let temp2 = temp2_m + temp2_f;

    //18-24
    //(P12_007N + P12_031N) + (P12_008N + P12_032N) + (P12_009N + P12_033N) + (P12_010N + P12_034N)
    let temp3_m =
      parseInt(data["P12_007N"]) +
      parseInt(data["P12_008N"]) +
      parseInt(data["P12_009N"]) +
      parseInt(data["P12_010N"]);
    let temp3_f =
      parseInt(data["P12_031N"]) +
      parseInt(data["P12_032N"]) +
      parseInt(data["P12_033N"]) +
      parseInt(data["P12_034N"]);
    let temp3 = temp3_m + temp3_f;

    //updated breakdowns:
    //25-29
    //P12_011N+ P12_035N
    let temp4_m = parseInt(data["P12_011N"]);
    let temp4_f = parseInt(data["P12_035N"]);
    let temp4 = temp4_m + temp4_f;

    //30-39
    //(P12_012N + P12_036N) + (P12_013N + P12_037N)
    let temp5_m = parseInt(data["P12_012N"]) + parseInt(data["P12_013N"]);
    let temp5_f = parseInt(data["P12_036N"]) + parseInt(data["P12_037N"]);
    let temp5 = temp5_m + temp5_f;

    //40-49
    //(P12_014N + P12_038N) + (P12_015N + P12_039N)
    let temp6_m = parseInt(data["P12_014N"]) + parseInt(data["P12_015N"]);
    let temp6_f = parseInt(data["P12_038N"]) + parseInt(data["P12_039N"]);
    let temp6 = temp6_m + temp6_f;

    //50-59
    //(P12_016N + P12_040N) + (P12_017N + P12_041N)
    let temp7_m = parseInt(data["P12_016N"]) + parseInt(data["P12_017N"]);

    let temp7_f = parseInt(data["P12_040N"]) + parseInt(data["P12_041N"]);
    let temp7 = temp7_m + temp7_f;

    //60+
    //(P12_018N + P12_042N) + (P12_019N + P12_043N)+(P12_020N + P12_044N) + (P12_021N + P12_045N) + (P12_022N + P12_046N) + (P12_023N + P12_047N) + (P12_024N + P12_048N) + (P12_025N + P12_049N)
    let temp8_m =
      parseInt(data["P12_018N"]) +
      parseInt(data["P12_019N"]) +
      parseInt(data["P12_020N"]) +
      parseInt(data["P12_021N"]) +
      parseInt(data["P12_022N"]) +
      parseInt(data["P12_023N"]) +
      parseInt(data["P12_024N"]) +
      parseInt(data["P12_025N"]);
    let temp8_f =
      parseInt(data["P12_042N"]) +
      parseInt(data["P12_043N"]) +
      parseInt(data["P12_044N"]) +
      parseInt(data["P12_045N"]) +
      parseInt(data["P12_046N"]) +
      parseInt(data["P12_047N"]) +
      parseInt(data["P12_048N"]) +
      parseInt(data["P12_049N"]);
    let temp8 = temp8_m + temp8_f;

    let total = parseInt(data["P12_001N"]);

    return [
      ["0-4", temp1],
      ["5-17", temp2],
      ["18-24", temp3],
      ["25-29", temp4],
      ["30-39", temp5],
      ["40-49", temp6],
      ["50-59", temp7],
      ["60+", temp8],
      ["Total", total],
    ];
  }

  processRaceAdultChildData = (data) => [
    [
      "Non-Hisp. White alone",
      parseInt(data.P9_005N),
      parseInt(data.P11_005N),
      parseInt(data.P9_005N) - parseInt(data.P11_005N),
    ],
    [
      "Non-Hisp. Black or African American alone",
      parseInt(data.P9_006N),
      parseInt(data.P11_006N),
      parseInt(data.P9_006N) - parseInt(data.P11_006N),
    ],
    [
      "Hispanic or Latino",
      parseInt(data.P9_002N),
      parseInt(data.P11_002N),
      parseInt(data.P9_002N) - parseInt(data.P11_002N),
    ],
    [
      "Non-Hisp. Asian, Native Hawaiian and Pacific Islander alone",
      parseInt(data.P9_008N) + parseInt(data.P9_009N),
      parseInt(data.P11_008N) + parseInt(data.P11_009N),
      parseInt(data.P9_008N) +
        parseInt(data.P9_009N) -
        parseInt(data.P11_008N) -
        parseInt(data.P11_009N),
    ],
    [
      "Non-Hisp. American Indian and Alaska Native alone",
      parseInt(data.P9_007N),
      parseInt(data.P11_007N),
      parseInt(data.P9_007N) - parseInt(data.P11_007N),
    ],
    [
      "Non-Hisp. Some Other Race alone",
      parseInt(data.P9_010N),
      parseInt(data.P11_010N),
      parseInt(data.P9_010N) - parseInt(data.P11_010N),
    ],
    [
      "Non-Hisp. Two or More Races",
      parseInt(data.P9_011N),
      parseInt(data.P11_011N),
      parseInt(data.P9_011N) - parseInt(data.P11_011N),
    ],
    [
      "Total",
      parseInt(data.P9_001N),
      parseInt(data.P11_001N),
      parseInt(data.P9_001N) - parseInt(data.P11_001N),
    ],
  ];

  processRaceAdultChildPercentData = (data) => {
    let adult_tot = parseInt(data.P11_001N);
    let child_tot = parseInt(data.P9_001N) - parseInt(data.P11_001N);
    let adult_white = parseInt(data.P11_005N);
    let adult_black = parseInt(data.P11_006N);
    let adult_hisp = parseInt(data.P11_002N);
    let adult_asia = parseInt(data.P11_008N) + parseInt(data.P11_009N);
    let adult_india = parseInt(data.P11_007N);
    let adult_other = parseInt(data.P11_010N);
    let adult_two = parseInt(data.P11_011N);
    let child_white = parseInt(data.P9_005N) - parseInt(data.P11_005N);
    let child_black = parseInt(data.P9_006N) - parseInt(data.P11_006N);
    let child_hisp = parseInt(data.P9_002N) - parseInt(data.P11_002N);
    let child_asia =
      parseInt(data.P9_008N) +
      parseInt(data.P9_009N) -
      parseInt(data.P11_008N) -
      parseInt(data.P11_009N);
    let child_india = parseInt(data.P9_007N) - parseInt(data.P11_007N);
    let child_other = parseInt(data.P9_010N) - parseInt(data.P11_010N);
    let child_two = parseInt(data.P9_011N) - parseInt(data.P11_011N);

    return [
      [
        "Non-Hisp. White alone",
        (adult_white / adult_tot).toPrecision(3) * 100,
        (child_white / child_tot).toPrecision(3) * 100,
      ],
      [
        "Non-Hisp. Black or African American alone",
        (adult_black / adult_tot).toPrecision(3) * 100,
        (child_black / child_tot).toPrecision(3) * 100,
      ],
      [
        "Hispanic or Latino",
        (adult_hisp / adult_tot).toPrecision(3) * 100,
        (child_hisp / child_tot).toPrecision(3) * 100,
      ],
      [
        "Non-Hisp. Asian, Native Hawaiian and Pacific Islander alone",
        (adult_asia / adult_tot).toPrecision(3) * 100,
        (child_asia / child_tot).toPrecision(3) * 100,
      ],
      [
        "Non-Hisp. American Indian and Alaska Native alone",
        (adult_india / adult_tot).toPrecision(3) * 100,
        (child_india / child_tot).toPrecision(3) * 100,
      ],
      [
        "Non-Hisp. Some Other Race alone",
        (adult_other / adult_tot).toPrecision(3) * 100,
        (child_other / child_tot).toPrecision(3) * 100,
      ],
      [
        "Non-Hisp. Two or More Races",
        (adult_two / adult_tot).toPrecision(3) * 100,
        (child_two / child_tot).toPrecision(3) * 100,
      ],
    ];
  };

  handleClickCode(code) {
    switch (code) {
      case "age":
        // setAgeOpen(!ageOpen);
        this.setState({ age: !this.state.age });
        break;
      case "gender":
        // setAgeOpen(!ageOpen);
        this.setState({ gender: !this.state.gender });
        break;
      case "race":
        // setNativityOpen(!nativityOpen);
        this.setState({ race: !this.state.race });
        break;
    }
  }
  render() {
    if (this.props.dataState.population && !this.state.loading) {
      return (
        <div>
          {this.props.dataState.population.data.map((part, index) => (
            <div key={index}>
              <ListItem
                button
                onClick={() => {
                  this.handleClickCode(part.id);
                }}
              >
                <ListItemText primary={part.title} />
                {this.state[part.id] ? <ExpandLess /> : <ExpandMore />}
              </ListItem>
              <VariableWithChart open={this.state[part.id]} info={part} />
            </div>
          ))}
        </div>
      );
    } else if (this.state.loading) {
      console.log("LOADING");
      return <LoadingBlock />;
    } else {
      return <EmptyMessage />;
    }
  }
}

const mapStateToProps = (state) => ({
  mapState: state.map,
  dataState: state.data,
});

export default connect(mapStateToProps)(Population2020);
