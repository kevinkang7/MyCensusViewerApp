import React from "react";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import LoadingBlock from "../public/LoadingBlock";
import { connect } from "react-redux";
import { processCsvData } from "../public/utils";
import { _loadCensus2020Data_DHC } from "../public/api_census";
import EmptyMessage from "../public/EmptyMessage";
import { updateHouseholds, clearData } from "../../redux/actions";
import VariableWithChart from "../public/VariableWithChart";

class Households extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      tenureRace: false,
      householdType: false,
      familyChildren: false,
      householdElders: false,
      averageSize: false,
    };
  }

  setDataToState = (props) => {
    const { layer, neighborhood } = this.props.mapState;
    this.setState({ loading: true });
    const tenureRacePromise = _loadCensus2020Data_DHC(props, "group(HCT1)");
    const householdTypePromise = _loadCensus2020Data_DHC(props, "group(P16)");
    const familyChildrenPromise = _loadCensus2020Data_DHC(
      props,
      "group(PCT10)"
    );
    const householdEldersPromise = _loadCensus2020Data_DHC(
      props,
      "group(PCT5)"
    );
    const householdPopulationPromise = _loadCensus2020Data_DHC(
      props,
      "group(H8)"
    );

    console.log(tenureRacePromise);
    console.log(householdTypePromise);

    Promise.all([
      tenureRacePromise,
      householdTypePromise,
      familyChildrenPromise,
      householdEldersPromise,
      householdPopulationPromise,
    ]).then((values) => {
      const tenureRaceHeader = [
        "Tenure by Race/Ethnicity of Householder",
        "Owner Occupied",
        "Renter Occupied",
      ];
      const householdTypeHeader = ["Household Type", "Count"];
      const familyChildrenHeader = [
        "Family Type",
        "With Own Children Under 18 Years",
        "No Own Children Under 18 Years",
      ];
      const householdEldersHeader = [
        "Households Size and Type",
        "Households with One or More People 60 Years and Over",
        "Households With No People 60 Years and Over",
      ];
      const averageSizeHeader = ["", "Average Household Size"];

      const tenureRaceData = this.processTenureRaceData(values[0][0]);
      const householdTypeData = this.processHouseholdTypeData(values[1][0]);
      const familyChildrenData = this.processFamilyChildrenData(values[2][0]);
      const householdEldersData = this.processHouseholdEldersData(values[3][0]);

      const householdTypeChartData = this.processHouseholdTypeChartData(
        values[1][0]
      );
      //build an object "hhPopData" to include household numbers and household population data
      const hhPopData = {
        ...values[0][0],
        ...values[4][0],
      };
      const averageSizeData = this.processAverageHouseholdSizeData(hhPopData);

      const hhPopData_csv = [];

      //combine the household table (HCT1) and the household population table (H8) to calculate average household size.

      if (layer === "tracts") {
        //create a new array, add the average of selected tracts first
        hhPopData_csv.push(hhPopData);
        hhPopData_csv[0]["NAME"] = "Selected Tract(s)";
      }

      //loop the selected tracts, combine the household table (HCT1) and the household population table (H8) to each tract
      for (let i = 0; i < values[4][1].length; i++) {
        hhPopData_csv.push({
          ...values[0][1][i],
          ...values[4][1][i],
        });
      }

      console.log(averageSizeData);
      console.log(hhPopData_csv);

      // const familyChildrenChartData = this.processFamilyChildrenChartData(
      //   values[2][0]
      // );

      console.log(values);
      console.log(values[2]);

      this.props.dispatch(
        updateHouseholds({
          selected: this.props.mapState.selected,
          data: [
            {
              id: "tenureRace",
              title: "Tenure by Race/Ethnicity of Householder",
              chart: "column",
              data: tenureRaceData,
              csv: processCsvData(
                values[0][1],
                this.processTenureRaceData,
                tenureRaceHeader,
                tenureRaceData,
                layer,
                neighborhood
              ),
              header: tenureRaceHeader,
              yCategory: ["Owner Occupied", "Renter Occupied"],
              tableID: "HCT1",
              universe: "Occupied housing units",
            },
            {
              id: "householdType",
              title: "Household Type",
              chart: "column",
              data: householdTypeData,
              chartData: householdTypeChartData,
              csv: processCsvData(
                values[1][1],
                this.processHouseholdTypeData,
                householdTypeHeader,
                householdTypeData,
                layer,
                neighborhood
              ),
              header: householdTypeHeader,
              yCategory: ["Count"],
              tableID: "P16",
              universe: "Households",
              notes:
                'Note: "Families" consist of a householder and one or more other people related to the householder by birth, marriage, or adoption.',
            },
            {
              id: "familyChildren",
              title: "Family Type by Presence of Own Children",
              chart: "columnNormal",
              data: familyChildrenData,
              //chartData: familyChildrenChartData,
              csv: processCsvData(
                values[2][1],
                this.processFamilyChildrenData,
                familyChildrenHeader,
                familyChildrenData,
                layer,
                neighborhood
              ),
              header: familyChildrenHeader,
              yCategory: [
                "With Own Children Under 18 Years",
                "No Own Children Under 18 Years",
              ],
              tableID: "PCT10",
              universe: "Families",
              notes:
                'Note: "Families" consist of a householder and one or more other people related to the householder by birth, marriage, or adoption.' +
                '\n"Own children" includes biological, adopted, and stepchildren of the householder.',
            },
            {
              id: "householdElders",
              title:
                "Households by Presence of People 60 Years and Over, Household Size, and Household Type",
              chart: "columnNormal",
              data: householdEldersData,
              csv: processCsvData(
                values[3][1],
                this.processHouseholdEldersData,
                householdEldersHeader,
                householdEldersData,
                layer,
                neighborhood
              ),
              header: householdEldersHeader,
              yCategory: [
                "Households with One or More People 60 Years and Over",
                "Households With No People 60 Years and Over",
              ],
              tableID: "PCT5",
              universe: "Households",
              notes:
                'Note: "Families" consist of a householder and one or more other people related to the householder by birth, marriage, or adoption.',
            },
            {
              id: "averageSize",
              title: "Average Household Size",
              chart: "",
              data: averageSizeData,
              csv: processCsvData(
                hhPopData_csv,
                this.processAverageHouseholdSizeData,
                averageSizeHeader,
                averageSizeData,
                layer,
                neighborhood
              ),
              header: averageSizeHeader,
              yCategory: "",
              tableID: "HCT1, H8",
              universe: "Households",
            },
          ],
        })
      );
      this.setState({ loading: false });
    });
  };

  componentDidMount() {
    const { mapState, dataState } = this.props;
    console.log(this.props);
    if (
      (!dataState.households ||
        dataState.households.selected !== mapState.selected) &&
      (mapState.selected.length !== 0 || mapState.layer == "city")
    ) {
      this.setDataToState(this.props);
    }
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevProps.mapState.selected !== this.props.mapState.selected) {
      if (
        this.props.mapState.selected.length !== 0 ||
        this.props.mapState.layer == "city"
      ) {
        this.setDataToState(this.props);
      } else {
        this.props.dispatch(clearData());
      }
    }
  }

  processTenureRaceData = (data) => [
    [
      "Non-Hisp. White alone",
      parseInt(data.HCT1_004N),
      parseInt(data.HCT1_021N),
    ],
    [
      "Non-Hisp. Black or African American alone",
      parseInt(data.HCT1_005N),
      parseInt(data.HCT1_022N),
    ],
    ["Hispanic or Latino", parseInt(data.HCT1_011N), parseInt(data.HCT1_028N)],
    [
      "Non-Hisp. Asian, Native Hawaiian and Pacific Islander alone",
      parseInt(data.HCT1_007N) + parseInt(data.HCT1_008N),
      parseInt(data.HCT1_024N) + parseInt(data.HCT1_025N),
    ],
    [
      "Non-Hisp. American Indian and Alaska Native alone",
      parseInt(data.HCT1_006N),
      parseInt(data.HCT1_023N),
    ],
    [
      "Non-Hisp. Some Other Race alone",
      parseInt(data.HCT1_009N),
      parseInt(data.HCT1_026N),
    ],
    [
      "Non-Hisp. Two or More Races",
      parseInt(data.HCT1_010N),
      parseInt(data.HCT1_027N),
    ],
    ["Total", parseInt(data.HCT1_002N), parseInt(data.HCT1_019N)],
  ];

  processHouseholdTypeData(data) {
    return [
      ["Family households", " "],
      [
        "\u00a0\u00a0\u00a0\u00a0 Married couple family",
        parseInt(data["P16_003N"]),
      ],
      [
        "\u00a0\u00a0\u00a0\u00a0 Other family: Male householder, no spouse present",
        parseInt(data["P16_005N"]),
      ],
      [
        "\u00a0\u00a0\u00a0\u00a0 Other family: Female householder, no spouse present",
        parseInt(data["P16_006N"]),
      ],
      ["Nonfamily households", " "],
      [
        "\u00a0\u00a0\u00a0\u00a0 Householder living alone",
        parseInt(data["P16_008N"]),
      ],
      [
        "\u00a0\u00a0\u00a0\u00a0 Householder not living alone",
        parseInt(data["P16_009N"]),
      ],
      ["Total", parseInt(data["P16_001N"])],
    ];
  }

  processHouseholdTypeChartData(data) {
    return [
      ["Family households: Married couple family", parseInt(data["P16_003N"])],
      [
        "Family households, other family: Male householder, no spouse present",
        parseInt(data["P16_005N"]),
      ],
      [
        "Family households, other family: Female householder, no spouse present",
        parseInt(data["P16_006N"]),
      ],
      [
        "Nonfamily households: Householder living alone",
        parseInt(data["P16_008N"]),
      ],
      [
        "Nonfamily households: Householder not living alone",
        parseInt(data["P16_009N"]),
      ],
      ["Total", parseInt(data["P16_001N"])],
    ];
  }

  processFamilyChildrenData = (data) => {
    return [
      [
        "Married couple family",
        parseInt(data["PCT10_003N"]),
        parseInt(data["PCT10_007N"]),
      ],
      [
        "Other family: Male householder, no spouse presents",
        parseInt(data["PCT10_010N"]),
        parseInt(data["PCT10_014N"]),
      ],
      [
        "Other family: Female householder, no spouse present",
        parseInt(data["PCT10_016N"]),
        parseInt(data["PCT10_020N"]),
      ],
      [
        "Total",
        parseInt(data["PCT10_003N"]) +
          parseInt(data["PCT10_010N"]) +
          parseInt(data["PCT10_016N"]),
        parseInt(data["PCT10_007N"]) +
          parseInt(data["PCT10_014N"]) +
          parseInt(data["PCT10_020N"]),
      ],
    ];
  };

  processHouseholdEldersData = (data) => [
    [
      "1-person household",
      parseInt(data["PCT5_003N"]),
      parseInt(data["PCT5_010N"]),
    ],
    [
      "2-or-more-person household: Family household",
      parseInt(data["PCT5_005N"]),
      parseInt(data["PCT5_010N"]),
    ],
    [
      "2-or-more-person household: Nonfamily household",
      parseInt(data["PCT5_006N"]),
      parseInt(data["PCT5_011N"]),
    ],
    ["Total", parseInt(data["PCT5_002N"]), parseInt(data["PCT5_007N"])],
  ];

  processAverageHouseholdSizeData = (data) => [
    [
      " ",
      (parseInt(data["H8_001N"]) / parseInt(data["HCT1_001N"])).toPrecision(3),
    ],
  ];

  handleClickCode(code) {
    switch (code) {
      case "tenureRace":
        this.setState({ tenureRace: !this.state.tenureRace });
        break;
      case "householdType":
        this.setState({ householdType: !this.state.householdType });
        break;
      case "familyChildren":
        this.setState({ familyChildren: !this.state.familyChildren });
        break;
      case "householdElders":
        this.setState({ householdElders: !this.state.householdElders });
        break;
      case "averageSize":
        this.setState({ averageSize: !this.state.averageSize });
        break;
    }
  }

  render() {
    console.log(this.props.dataState.households);
    if (this.props.dataState.households && !this.state.loading) {
      return (
        <div>
          {this.props.dataState.households.data.map((part, index) => (
            <div key={index}>
              <ListItem
                button
                onClick={() => {
                  this.handleClickCode(part.id);
                }}
              >
                <ListItemText primary={part.title} />
                {this.state[part.id] ? <ExpandLess /> : <ExpandMore />}
              </ListItem>
              <VariableWithChart open={this.state[part.id]} info={part} />
            </div>
          ))}
        </div>
      );
    } else if (this.state.loading) {
      console.log("LOADING");
      return <LoadingBlock />;
    } else {
      return <EmptyMessage />;
    }
  }
}

const mapStateToProps = (state) => ({
  mapState: state.map,
  dataState: state.data,
});

export default connect(mapStateToProps)(Households);
