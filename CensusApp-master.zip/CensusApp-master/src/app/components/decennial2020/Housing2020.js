import React from "react";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import LoadingBlock from "../public/LoadingBlock";
import { connect } from "react-redux";
import { processCsvData } from "../public/utils";
import { _loadCensus2020Data_DHC } from "../public/api_census";
import EmptyMessage from "../public/EmptyMessage";
import { updateHousing, clearData } from "../../redux/actions";
import VariableWithChart from "../public/VariableWithChart";

class Housing2020 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      occupancy: false,
      tenure: false,
      vacancy: false,
    };
  }

  setDataToState = (props) => {
    const { layer, neighborhood } = this.props.mapState;
    this.setState({ loading: true });
    const occupancyPromise = _loadCensus2020Data_DHC(props, "group(H3)");
    const tenurePromise = _loadCensus2020Data_DHC(props, "group(H4)");
    const vacancyPromise = _loadCensus2020Data_DHC(props, "group(H5)");
    Promise.all([occupancyPromise, tenurePromise, vacancyPromise]).then(
      (values) => {
        const occupancyHeader = ["Occupancy Status", "Count"];
        const tenureHeader = ["Housing Tenure", "Count"];
        const vacancyHeader = ["Vacancy", "Count"];

        const occupancyData = this.processOccupancyData(values[0][0]);
        const tenureData = this.processTenureData(values[1][0]);
        const vacancyData = this.processVacancyData(values[2][0]);

        console.log(values);
        console.log(values[2]);

        this.props.dispatch(
          updateHousing({
            selected: this.props.mapState.selected,
            data: [
              {
                id: "occupancy",
                title: "Occupancy Status",
                chart: "pie",
                data: occupancyData,
                csv: processCsvData(
                  values[0][1],
                  this.processOccupancyData,
                  occupancyHeader,
                  occupancyData,
                  layer,
                  neighborhood
                ),
                header: occupancyHeader,
                yCategory: ["Count"],
                tableID: "H3",
                universe: "Housing units",
              },
              {
                id: "tenure",
                title: "Housing Tenure",
                chart: "pie",
                data: tenureData,
                csv: processCsvData(
                  values[1][1],
                  this.processTenureData,
                  tenureHeader,
                  tenureData,
                  layer,
                  neighborhood
                ),
                header: tenureHeader,
                yCategory: ["Count"],
                tableID: "H4",
                universe: "Occupied housing units",
              },
              {
                id: "vacancy",
                title: "Detailed Vacancy Status",
                chart: "column",
                data: vacancyData,
                csv: processCsvData(
                  values[2][1],
                  this.processVacancyData,
                  vacancyHeader,
                  vacancyData,
                  layer,
                  neighborhood
                ),
                header: vacancyHeader,
                yCategory: ["Count"],
                tableID: "H5",
                universe: "Vacant housing units",
              },
            ],
          })
        );
        this.setState({ loading: false });
      }
    );
  };

  componentDidMount() {
    const { mapState, dataState } = this.props;
    if (
      (!dataState.housing ||
        dataState.housing.selected !== mapState.selected) &&
      (mapState.selected.length !== 0 || mapState.layer == "city")
    ) {
      this.setDataToState(this.props);
    }
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevProps.mapState.selected !== this.props.mapState.selected) {
      if (
        this.props.mapState.selected.length !== 0 ||
        this.props.mapState.layer == "city"
      ) {
        this.setDataToState(this.props);
      } else {
        this.props.dispatch(clearData());
      }
    }
  }

  processOccupancyData(data) {
    return [
      ["Occupied", parseInt(data["H3_002N"])],
      ["Vacant", parseInt(data["H3_003N"])],
      ["Total", parseInt(data["H3_001N"])],
    ];
  }

  processTenureData(data) {
    return [
      ["Owner occupied", parseInt(data["H4_002N"]) + parseInt(data["H4_003N"])],
      ["Renter occupied", parseInt(data["H4_004N"])],
      ["Total", parseInt(data["H4_001N"])],
    ];
  }

  processVacancyData(data) {
    return [
      ["For rent", parseInt(data["H5_002N"])],
      ["Rented, not occupied", parseInt(data["H5_003N"])],
      ["For sale only", parseInt(data["H5_004N"])],
      ["Sold, not occupied", parseInt(data["H5_005N"])],
      [
        "For seasonal, recreational, or occasional use",
        parseInt(data["H5_006N"]),
      ],
      ["For migrant workers", parseInt(data["H5_007N"])],
      ["Other vacant", parseInt(data["H5_008N"])],
      ["Total", parseInt(data["H5_001N"])],
    ];
  }

  handleClickCode(code) {
    switch (code) {
      case "occupancy":
        this.setState({ occupancy: !this.state.occupancy });
        break;
      case "tenure":
        this.setState({ tenure: !this.state.tenure });
        break;
      case "vacancy":
        this.setState({ vacancy: !this.state.vacancy });
        break;
    }
  }

  render() {
    console.log(this.props.dataState.housing);
    if (this.props.dataState.housing && !this.state.loading) {
      return (
        <div>
          {this.props.dataState.housing.data.map((part, index) => (
            <div key={index}>
              <ListItem
                button
                onClick={() => {
                  this.handleClickCode(part.id);
                }}
              >
                <ListItemText primary={part.title} />
                {this.state[part.id] ? <ExpandLess /> : <ExpandMore />}
              </ListItem>
              <VariableWithChart open={this.state[part.id]} info={part} />
            </div>
          ))}
        </div>
      );
    } else if (this.state.loading) {
      console.log("LOADING");
      return <LoadingBlock />;
    } else {
      return <EmptyMessage />;
    }
  }
}

const mapStateToProps = (state) => ({
  mapState: state.map,
  dataState: state.data,
});

export default connect(mapStateToProps)(Housing2020);
