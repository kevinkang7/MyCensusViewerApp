import React from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import style from './PieChart.css';

let PieChart = (props) => {
  const { data, chartData } = props;

  let chart = chartData ? chartData : data;

  const options = {
    title: undefined,
    tooltip: {
      pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
    },
    accessibility: {
      point: {
        valueSuffix: '%',
      },
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        dataLabels: {
          enabled: true,
          format: '<b>{point.name}</b>: {point.y}',
        },
      },
    },
    chart: {
      type: 'pie',
    },
    series: [
      {
        name: 'Percentage',
        colorByPoint: true,
        data: chart
          ? chart.filter((item) => (item[0].includes('Total') ? false : true))
          : undefined,
      },
    ],
  };
  return (
    <div className={style.container}>
      <HighchartsReact highcharts={Highcharts} options={options} />
    </div>
  );
};

export default PieChart;
