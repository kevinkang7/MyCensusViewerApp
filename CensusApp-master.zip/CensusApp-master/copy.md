# BPDA Census Viewer <!-- omit from toc -->

[![screenshot.png](https://i.postimg.cc/3RntHW2p/screenshot.png)](https://postimg.cc/cgtRRx94)
- [About](#about)
- [Current Data](#current-data)
- [Getting Started](#getting-started)
- [Repo History](#repo-history)
- [Deployed Application](#deployed-application)
- [Decennial Census Map Update Overview 08/17/2023](#decennial-census-map-update-overview-08172023)

## About
MyCensus Viewer is an interactive map product that visualizes U.S. Census data for Boston. It includes two maps built upon separate U.S. Census survey datasets: the Decennial Census and the American Community Survey (ACS). 

Built with React, ArcGIS JavaScript API 4.x, and Material-UI

## Current Data
As of June 2023 the data publication years for the application are:
- **ACS:** 2017-2021
- **Decennial Census:** 2020
 
## Getting Started
1. Clone the repo
2. Use [nvm](https://github.com/nvm-sh/nvm) to downgrade your terminal to Node v16.
    ```
    nvm use 16
    ```

    If you are new to nvm, you will need to install version 16. Instructions here: [nvm](https://github.com/nvm-sh/nvm)
3. Run `npm install`
4. See if the code is working in its current state by running `npm run`
    * If you try `npm run` without downgrading to Node v16, you will get an error message along the lines of `error:0308010C:digital envelope routines::unsupported`
   
## Repo History
In some cases or in troubleshooting, it may be important to understand the history of how this app has been maintained. 

MyCensusViewer was originally created Piaotian Jin. During this time the repo was maintained on bitbucket, here <https://bitbucket.org/BostonRedevelop/censusapp-deprecated/>. This bitbucket repo is now **DEPRECEATED** and should not be cloned or modified.

Piaotian trained a member of the BPDA Research team, Kevin Fang, on how to maintain it. 
After Piaotian left the BPDA, Kevin continued to maintain the application locally on his computer from 2021-2022. The remote repository was not updated with his maintenance during this time.

In 2022/2023, the BPDA changed platforms from Bitbucket to GitLab. 

In 2023, the remote repo from Bitbucket was migrated over to GitLab, here: <https://gitlab.com/boston-plans/CensusApp>

In 2023, we took the code Kevin had been maintaining locally and merged it with the remote repository, intergrating his code into the master branch. From this point on, it was maintained via the remote repository.

## Deployed Application
<https://www.bostonplans.org/research/mycensus-viewer>

## Decennial Census Map Update Overview 08/17/2023

We remade components in the decennial2020, making the structure similar to ACS.  

**Layers**

- Replace the 2020 Census block group layer with the 2020 Census tract layer.
- Replace the 2020 Census block group neighborhood layer with the 2020 Census tract neighborhood layer.

**Topics and Tables**

- Add Age and Sex tables to the “Population” topic. Combine adult and child population charts into one, displaying population shares by race/ethnicity.
- Add the “Households” topic with the four tables:
    - Tenure by householder Race/Ethnicity
    - Household Type
    - Family Type by Presence and Age of Own Children
    - Households by Presence of People 60 Years and Over, Household Size, and Household Type
- Add Housing Tenure and Detailed Vacancy Status tables to the “Housing” topic.

**Component Updates**

Retire previous components.js to retired folders for reference.

**Map.js Combine:**

- Move Map.js from the ACS folder to the public folder
- Delete Map2020.js from the decennial2020 folder, since now we want to use the tract and tract-based neighborhoods to replace block groups and block group based neighborhoods

**Add Households.js** 

**SketchWidgetPaperPie.js**

in the Decennial Viewer geographic panel, replace the block groups option with the tracts, making the geographic selection panel the same between ACS and Decennial Census. 

**Future Improvement**

- Unpack utils.js making it easier to read

- Summarize Promise/then,  methods async ()=> {await} methods for api_census.js, making GroupQuarters.js retrieving data method to be the same.

- Delete redundant codes. Making it more efficient
